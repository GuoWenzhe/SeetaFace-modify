#ifndef STRING_STRING_UTIL_GBK_H_
#define STRING_STRING_UTIL_GBK_H_
#include <string>
#include <iostream>

namespace sn_common
{
    bool isGBKCH(unsigned char ch1, unsigned char ch2);
    bool isGBKStr(const std::string& s);

    bool isGBKPunct(const std::string& str);
    std::string substrgbk(const std::string& s, int pos, int cnt);
    void strlowergbk(std::string &s);
    void struppergbk(std::string &s);
}

inline bool sn_common::isGBKCH(unsigned char ch1, unsigned char ch2)
{
    return ( (ch2 >= 64) && (ch2 <= 254) && (ch2 != 127) &&
            ((ch1 >= 129 && ch1 <= 160) || (ch1 >= 170 && ch1 < 254) ||
             (ch1 == 254 && ch2 <= 160)));
}

inline bool sn_common::isGBKStr(const std::string& s)
{
    size_t l = s.size();
    for (size_t i = 0; i < l;)
    {
        if (s[i] < 0 && i + 1 < l)
        {
            if (!isGBKCH(s[i], s[i + 1])) 
            {
                return false;
            }
            i += 2;
        }
        else
            return false;
    }

    return true;
}


inline bool sn_common::isGBKPunct(const std::string& str)
{
    if (str.empty() || str.size() > 2)
    {
        return false;
    }
    if (1 == str.size())
    {
        return (str[0] > 0 && !isalnum(str[0]));
    }
    if (str[0] < 0)
    {
        return (!isGBKCH((unsigned char)(str[0]),(unsigned char)(str[1])));
    }
    return false;
}
    inline std::string sn_common::substrgbk(const std::string& s, int pos, int cnt)
    {
        int i = 0; 
        int l = s.size();
        int n = 0;

        std::string s2;

        while(i<l && n<pos){i += (s[i]<0) ? 2 : 1; n++;}
        while(i<l && cnt>0)
        {
            if(s[i]<0)
            {
                s2 += s.substr(i, 2);
                i++;
            }
            else
            {
                s2 += s[i];
            }
            i++;
            cnt--;
        }

        return s2;
    }

    inline void sn_common::strlowergbk(std::string &s)
    {
        int n = 'A' - 'a';
        for(size_t i=0; i<s.size(); ++i)
        {
            if(s[i] < 0)
            {
                i++;
                continue;
            }
            if(s[i]>='A' && s[i]<='Z')
                s[i] = s[i] - n;
        }
    }

    inline void sn_common::struppergbk(std::string &s)
    {
        int n = 'A' - 'a';
        for(size_t i=0; i<s.size(); ++i)
        {
            if(s[i] < 0)
            {
                i++;
                continue;
            }
            if(s[i]>='a' && s[i]<='z')
                s[i] = s[i] + n;
        }
    }

#endif  //----end of STRING_STRING_UTIL_GBK_H_ 
