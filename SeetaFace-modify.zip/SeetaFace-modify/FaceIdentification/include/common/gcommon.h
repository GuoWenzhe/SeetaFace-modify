#ifndef GCOMMON_H
#define GCOMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <iostream>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <sys/mman.h>			  //mmap
#include <sys/types.h>			 //fstat
#include <sys/stat.h>
#include <sys/timeb.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>

#include <string>
#include <deque>
#include <map>
#include <ext/hash_map>

#include <semaphore.h>
#include <errno.h>

#include <glog/logging.h>			//glog
#include "profile.h"				//profile
#include "net_message.h"			//net message
#include "./pb/image_search.pb.h"		//proto buf


using namespace std;
using namespace __gnu_cxx;
using namespace sn_common;
using namespace net_message;
using namespace image_search_pb;

#define LENGTH_MD5			32	 //MD5长度
#define LENGTH_PRODUCT_CODE	32	 //产品编码长度
#define LENGTH_SHOP_ID		32	 //店铺编码
#define LENGTH_IMAGE_ID		16	 //图片下标
//#define LENGTH_IMAGE_INFO	33	 //MD5文件中图片信息，格式：店铺ID_商品编码_图片下标


#define IMAGE_CATEGORY_MAX		2048
//#define IMAGE_FEATRUE_NUM		4096
#define IMAGE_FEATRUE_NUM		1000	
/*******************Message Type Define*************************/
#define MESSTYPE_AS2BS_PROBE		0
#define MESSTYPE_BS2AS_PROBE_REP	1

#define MESSTYPE_AS2CS_PROBE		2
#define MESSTYPE_CS2AS_PROBE_REP	3

#define MESSTYPE_AS2BS_REQUEST	4
#define MESSTYPE_BS2AS_RESPONSE	5

#define MESSTYPE_AS2CS_REQUEST	6
#define MESSTYPE_CS2AS_RESPONSE	7

#define MESSTYPE_AS2TS_PROBE     8
#define MESSTYPE_TS2AS_PROBE_REP 9

#define MESSTYPE_AS2TS_REQUEST   10
#define MESSTYPE_TS2AS_RESPONSE  11

#define ERROR_SUCCED			0  //搜索结果成功
#define ERROR_SOCKET			1  //socket异常
#define ERROR_QUERY				2  //查询请求格式异常
#define ERROR_EXTRACT_FEATURE	4  //抽取特征异常
#define ERROR_BS_ERROR			5  //BS无响应
#define ERROR_IMAGE_DATA		6  //图像数据错误
#define ERROR_NO_PRODUCT_INFO	7  //无法获取商品信息
#define ERROR_WEB_PROBEL		8  //web的探测消息
#define ERROR_CLEAR_CACHE		9  //清楚缓存消息cash
#define ERROR_HAND_CUTE			10  //无效的主体信息

#define ERROR_DESC_SUCCED		"Succed"				  //搜索结果成功
#define ERROR_DESC_SOCKET		"Socket Error"		  //socket异常
#define ERROR_DESC_QUERY		"Query Format Error"  //查询请求格式异常
#define ERROR_DESC_EXTRACT_FEATURE	"EXtract Image Feature Error"  //抽取特征异常
#define ERROR_DESC_BS_ERROR			"No Response From BS"  //BS无响应
#define ERROR_DESC_IMAGE_DATA	  	"Invalid Image Data"  //无效的图片数据
#define ERROR_DESC_NO_PRODUCT_INFO	"NO PRODUCT INFO"  	//无法获取商品信息
#define ERROR_DESC_WEB_PROBEL		"As Normal"  		//web的探测消息
#define ERROR_DESC_CLEAR_CACHE_SUCC	"Clear Cache Succ"  	//清楚缓存成功
#define ERROR_DESC_CLEAR_CACHE_FAIL	"Clear Cache Fail"  	//清楚缓存失败
#define ERROR_DESC_HAND_CUTE       "Invalid Hand Cute Data"  //无效的主体信息

#define SEARCH_TYPE_PIC 0
#define SEARCH_TYPE_SIMILAR 1
/*******************Struct Define******************************/
struct SPICIdx{
	  char chMD5[LENGTH_MD5+1];
	  int  nNum;
};

struct SImageIdx{
    uint64_t uGdsId;
    uint64_t uStoreId;
    uint16_t uOrd;
	SImageIdx(){
        uGdsId=0;
        uStoreId=0;
        uOrd=0;
    }
    friend bool operator < (const SImageIdx&a, const SImageIdx&b)
    {
        if(a.uGdsId != b.uGdsId)
        {
            return a.uGdsId < b.uGdsId;  //升序
        }
        else if(a.uStoreId != b.uStoreId)
        {
            return a.uStoreId < b.uStoreId;
        }
        else
        {
            return a.uOrd < b.uOrd;
        }
    }
};


//分类偏移量
struct SCateOffset
{
	int nCate;
	int nStart;
	int nLen;

	SCateOffset(){
		memset(this, 0, sizeof(*this));
	};
};
typedef struct SCateOffset SCateOffset;

//分类权重
struct SCateWeight
{
	int nCate;
	float fWeight;
	
	SCateWeight(){
		memset(this, 0, sizeof(*this));
	};
	friend bool operator < (struct SCateWeight const&A, struct SCateWeight const&B)
	{  
		//按权重降序排列
		if(A.fWeight!=B.fWeight)
			return A.fWeight>B.fWeight;	
		else
			return A.nCate<B.nCate; 
	}	
};
typedef struct SCateWeight SCateWeight;

//产品分类信息
struct SProductGroup
{
	size_t sizeGroupId;
	char chGroupName[128]; 
	SProductGroup(){
		memset(this, 0, sizeof(*this));
	};
};
typedef struct SProductGroup SProductGroup;

struct SProductGroupCount
{
	size_t sizeGroupId;
	char chGroupName[128]; 
	int count;
	SProductGroupCount(){
		memset(this, 0, sizeof(*this));
	};
	//Asc
	friend bool operator < (struct SProductGroupCount const&A, struct SProductGroupCount const&B)
	{
		return A.count>B.count;
	}	
};
typedef struct SProductGroupCount SProductGroupCount;


//BS对象
struct SBS
{
	CNetClientConnection oConnBS;
	size_t nRow;
	size_t nCol;
	bool bBSGood;
	SBS(){
		nRow= 0;
		nCol= 0;
		bBSGood= true;
	};
};
typedef struct SBS	SBS;

//图片MD5：得分
struct SImageMD5Score
{
	char chImageMD5[33];
	float fScore;
	SImageMD5Score(){
		memset(this, 0, sizeof(*this));
	};

	friend bool operator < (struct SImageMD5Score const&A, struct SImageMD5Score const&B)
	{
		if(A.fScore!=B.fScore)  
			return A.fScore>B.fScore;  //降序排列
		else
			 return strcmp(A.chImageMD5,B.chImageMD5)<0;
	}
};
typedef struct SImageMD5Score SImageMD5Score;


class stringhasher
{
public:
	enum {
			bucket_size = 1,
			min_buckets = 400000
	};

	size_t operator()(const string &s)const
	{
		size_t h = 0;
		string::const_iterator p, p_end;
		for(p = s.begin(), p_end = s.end(); p != p_end; ++p)
		{
			h = 101 * h + (*p);
		}
		return h;
	}

	bool inline operator() (const string& s1, const string& s2) const
	{
		return s1 < s2;
	}
};

enum GPU_SERVER
{
	CS =1,TS
};

//BS对象
struct SGPUS
{
	enum GPU_SERVER SType;
	size_t nID;
	CNetClientConnection oConn;
	bool bGood;
	SGPUS(){
		SType= CS;
		nID= 0;
		bGood= true;
	};
	
};
typedef struct SGPUS	SGPUS;

struct structProInfoA
{ 
	string strCode;
	string strImageCode;//保存信息包含图片ID, 0070137178_159765328_5
	float fScore;

	structProInfoA()
	{
		fScore=0.0f;
	}
};
typedef struct structProInfoA structProInfoA;

struct structProInfoB
{ 
	string strCode;
	string strDesc; 
	string strCate; 
	string strCateDesc;
	//string strArticalCount;
	int nArticalCount;
	string strShopName;
	string strShopId;
	string strShopType;
	string strImageCode;//保存信息包含图片ID, 0070137178_159765328_5
	int nSellCount;
	float fScore;
	float fRankScore;
	string strTrademarks;
	structProInfoB()
	{
		fScore=0.0f;
		fRankScore=0.0f;
		nSellCount= 0;
		nArticalCount= 0;
	}
};
typedef struct structProInfoB structProInfoB;

struct structRect
{ 
	int x1;
	int y1;
	int x2;
	int y2;
	
	structRect()
	{
		x1= 0;
		y1= 0;
		x2= 0;
		y2= 0;
	}
};
typedef struct structRect sRect;


struct StructWebQuery
{
	int nError;//
	int nHandCute;//是否手动圈选	0：未圈选 1：已经圈选
	int nSearchType;//0:图片搜索 1:相似商品
	string strImageCode;//图片编码"0070078374_142151915_1"
	string strPCode;//商品编码"0070078374_142151915"
	string strPCate;//商品分类
	string strCityID;//城市ID
	string strImageData;	//解码前的图像数据
	
	uint64_t nMd5;//搜索相似商品的key值
	sRect rect;//主体位置
	vector <unsigned char> vecImageData;  //解码后的图片信息
	StructWebQuery()
	{
		nError=ERROR_SUCCED;
		nSearchType=SEARCH_TYPE_PIC;
		nHandCute=0;
		nError=0;
		nMd5= 0;
		
	}
};
typedef struct StructWebQuery StructWebQuery;
/*******************************************************
*
*	global fuction
*******************************************************/


#endif
