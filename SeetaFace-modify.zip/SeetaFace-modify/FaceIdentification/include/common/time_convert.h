#ifndef SYSTEM_TIME_CONVERT_H
#define SYSTEM_TIME_CONVERT_H

#include <time.h>
#include <inttypes.h>
#include <string>
#include <assert.h>

namespace sn_common
{
//时间操作
struct STime
{
	uint16_t year;
	uint8_t month;
	uint8_t day;
	uint8_t hour;
	uint8_t minute;
	uint8_t second;
	uint8_t week_day;

	STime();
};
//时间转成指定格式的结构体
bool SplitTime(time_t nTime, STime &oTime);
bool JoinTime(const STime &oTime, time_t &nTime);
//时间转字符串 
bool TimeToStr(time_t nTime, std::string &strTime, bool bShowWeekDay = false);
//字符串转时间
bool StrToTime(const std::string &strTime, time_t &nTime);
std::string TimeToStr(time_t nTime = time(NULL), bool bShowWeekDay = false);

}

#endif

