/***************************************
 * This program is intended to provide
 * some functions to read & write .INI
 * format file in OS other than Windows
 *
 * FORMAT:
 * [section]
 * entry=value
 * any line begin with '#' is ignored
 *
 *
 ***************************************/
#ifndef CONFIGURATION_PROFILE_H
#define CONFIGURATION_PROFILE_H 


namespace sn_common {

 /**
 *  write an integer entry to the profile
 *  
 *  @param[in]  profile: the name of the profile. If the file doesn't exists,
 *						 a new file will be created
 *  			section: the name of a section. If no such section
 *   	  				 exists, the section will be inserted into the profile.
 *  			entry:   the name of an entry to be added or updated.
 *  			value:   the value of the entry.
 *  @param[out] ��
 *  @return 0: any error occurrs
  			other: successful
 *  @note 
 */
int WriteProfileInt(const char* profile, const char* section, const char* entry, int value);
/**
*  write an unsigned integer entry to the profile
*  
*  @param[in]  profile: the name of the profile. If the file doesn't exists,
*						a new file will be created
*			   section: the name of a section. If no such section
*						exists, the section will be inserted into the profile.
*			   entry:	the name of an entry to be added or updated.
*			   value:	the value of the entry.
*  @param[out] ��
*  @return 0: any error occurrs
		   other: successful
*  @note 
*/
int WriteProfileUInt(const char* profile, const char* section, const char* entry, unsigned int value);
 /**
 *  write an string entry to the profile
 *  
 *  @param[in]  profile: the name of the profile. If the file doesn't exists,
 *						 a new file will be created
 *  			section: the name of a section. If no such section
 *   	  				 exists, the section will be inserted into the profile.
 *  			entry:   the name of an entry to be added or updated.
 *  			value:   the value of the entry.
 *  @param[out] ��
 *  @return 0: any error occurrs
  			other: successful
 *  @note 
 */
int WriteProfileString(const char* profile, const char* section, const char* entry, const char* value);
/**
 *  get the value of an int entry from the profile
 *  
 *  @param[in]  profile: the name of the profile. 
 *  			section: the name of a section. 
 *  			entry:   the name of an entry to look for
 *  			def:     the default value to set if the given entry
 * 		                 doesn't exist.
 *  @param[out] ��
 *  @return  :  the value
 *  @note 
 */
int GetProfileInt(const char* profile, const char* section, const char* entry, int def);
/**
 *  get the value of an unsigned int entry from the profile
 *  
 *  @param[in]  profile: the name of the profile. 
 *  			section: the name of a section. 
 *  			entry:   the name of an entry to look for
 *  			def:     the default value to set if the given entry
 * 		                 doesn't exist.
 *  @param[out] ��
 *  @return :  the valuel
 *  @note 
 */
unsigned int GetProfileUInt(const char* profile, const char* section, const char* entry, unsigned int def);

/**
 *	get the value of an string entry from the profile
 *	
 *	@param[in]	profile: the name of the profile. 
 *				section: the name of a section. 
 *				entry:	 the name of an entry to look for
 *				def:	 the default value to set if the given entry
 *						 doesn't exist.
 *	@param[out] ret:     the buffer to store the result
 *				size:    the size of buffer result buffer
 *	@return 0: any error occurrs
 *         >0: the number of bytes stored in the buffer
 *	@note 
 */
int GetProfileString(const char* profile, const char* section, const char* entry, const char* def, char* ret, int size);
/**
 *	get a series of values of an entry from the profile
 *	
 *	@param[in]	profile: the name of the profile. 
 *				section: the name of a section. 
 *				entry:	 the name of an entry to look for
 *				deli:    the delimeter
 *	@param[out] ret:	 the pointer to store the result
 *	@return 0: any error occurrs
 *         >0: the number of values stored in the ret, [NOTE]which must be freed after using it
 *	@note 
 */
int GetProfileStrings(const char* profile, const char* section, const char* entry, char*** ret, const char* deli);

/**
 *	free string memory
 *	
 *	@param[in]	strs: the pointer to store the string pointers to free. 
 *				count: the count of string pointers in strs 
 *	@param[out] 
 *	@return 
 *	@note 
 */
void FreeStrings(char** strs, int count);
 /**
 *	get a series of values of an int entry from the profile, with the delimter ',', ' ' or '\t'
 *	
 *	@param[in]	profile: the name of the profile. 
 *				section: the name of a section. 
 *				entry:	 the name of an entry to look for
 *	@param[out] ret:	 the pointer to store the result
 *	@return 0: any error occurrs
 *         >0: the number of values stored in the ret, [NOTE]which must be freed after using it
 *	@note 
 */
int GetProfileInts(const char* profile, const char* section, const char* entry, int** ret);
 /**
 *	get a series of values of an unsigned int entry from the profile, with the delimter ',', ' ' or '\t'
 *	
 *	@param[in]	profile: the name of the profile. 
 *				section: the name of a section. 
 *				entry:	 the name of an entry to look for
 *	@param[out] ret:	 the pointer to store the result
 *	@return 0: any error occurrs
 *         >0: the number of values stored in the ret, [NOTE]which must be freed after using it
 *	@note 
 */ 
int GetProfileUInts(const char* profile, const char* section, const char* entry, unsigned int** ret);
 
int GetProfileBuffer(const char* profile, const char* section, const char* entry, const char* def, char* ret, int size);
}

#endif
