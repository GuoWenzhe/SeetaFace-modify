#ifndef _XML_HTTP_H_
#define _XML_HTTP_H_

#include <string>
#include <iconv.h>
#include <ext/hash_map>

using namespace std;
using namespace __gnu_cxx;

#define ADD_INT_XMLNODE(xml,chBuf,nodeName,value) {sprintf(chBuf, "<%s>%d</%s>\n", nodeName,value,nodeName);             xml += chBuf;}

class cxmlhttp
{
public:
	string& xmlencode(const char *str, string& s);
	string& xmlpacktext(const char *str, string& s) ;
//	int parserequest(string strRecvPara,hash_map<string,string>& hmStrStr);
	 
	bool utf8togbk(const std::string&, std::string&);

        string urlencode(string sIn);
	string urldecode(const string& in);

	cxmlhttp();
	virtual ~cxmlhttp();
private:
	char char2hex(char ch)
	{
		if(ch>='A' && ch<='Z')
			return ch-'A'+10;
		if(ch>='a' && ch<='z')
			return ch-'a'+10;
		if(ch>='0' && ch<='9')
			return ch-'0';
		return 0;
	}


	inline char hex2char(char c1,char c2)
	{
		return (char2hex(c1)<<4) + char2hex(c2);
	}
	inline unsigned char toHex(const unsigned char &x)
	{
		return  x > 9 ? x + 55: x + 48;
	}

	short hexChar2dec(char c)
	{
		if ( '0'<=c && c<='9' ) {
			return short(c-'0');
		} else if ( 'a'<=c && c<='f' ) {
			return ( short(c-'a') + 10 );
		} else if ( 'A'<=c && c<='F' ) {
			return ( short(c-'A') + 10 );
		} else {
			return -1;
		}
	}
};


#endif

