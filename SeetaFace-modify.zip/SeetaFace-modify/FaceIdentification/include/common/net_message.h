#ifndef NETMESSAGE_NET_MESSAGE_H
#define NETMESSAGE_NET_MESSAGE_H

#include <inttypes.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <assert.h>
#include <sys/timeb.h>
#include <pthread.h>
#include <set>
#include <map>
#include <list>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <ext/hash_map>


namespace sn_common
{
namespace net_message
{

class CNetMessageHead
{
public:
	uint64_t nSerialNo;
	uint32_t nDataLen;
	uint8_t nMessageType;
	uint8_t nReserved1;
	uint16_t nReserved2;

	CNetMessageHead();
};

class CNetMessage
{
public:
	CNetMessageHead oHead;
	std::string strData;

	void SetData(uint8_t nMessageType, const void *p, uint32_t len);
	const void *GetData() const;
	uint8_t GetMessageType() const;
	uint32_t GetDataLen() const;
};

class CNetSock
{
public:
	int nSock;
	std::string strInputBuffer;
	std::string strOutputBuffer;
	timeb tmLastActive;

	void Init();
	CNetSock();
	~CNetSock();
};

class CNetClientConnection;

class CNetClientInteraction
{
public:
	enum EStatus
	{
		sUncomplete,
		sSucc,
		sFail
	};
	CNetClientConnection *pConn;
	bool bNeedRequest, bNeedResponse;
	CNetMessage oRequestMsg, oResponseMsg;
	EStatus eRequestStatus, eResponseStatus;

	CNetClientInteraction();
};

class CNetClientInteractionList
{
public:
	CNetClientInteraction *pInteractions;
	uint32_t nLen;
	timeb tmTargetTime;
	bool bSignal;
	pthread_cond_t cond;

	CNetClientInteractionList();
	~CNetClientInteractionList();
};

typedef std::pair<int, uint64_t> CSocket2SerialNoPair;

class CSocket2SerialNoComp
{
public:
	bool operator()(const CSocket2SerialNoPair &v1, const CSocket2SerialNoPair &v2)
	{
		if (v1.first != v2.first)
			return v1.first < v2.first;
		else if (v1.second != v2.second)
			return v1.second < v2.second;
		else
			return false; //equal
	}
};

class CNetClientConnection
{
private:
	typedef std::set<CNetClientInteractionList *> CWaitSet;
	typedef __gnu_cxx::hash_map<uint64_t, CNetClientInteraction *> CSerialNo2InteractionMap;
	typedef __gnu_cxx::hash_map<int, CNetClientInteraction *> CSocket2InteractionMap;
	typedef __gnu_cxx::hash_map<int, CNetClientConnection *> CSocket2ConnectionMap;
	typedef std::set<CSocket2SerialNoPair, CSocket2SerialNoComp> CSocket2SerialNoSet;

	static pthread_mutex_t lock;
	static CWaitSet setWait;
	static CSerialNo2InteractionMap mapSerialNo2Interaction;
	static CSocket2InteractionMap mapSocket2Interaction;
	static CSocket2ConnectionMap mapSocket2Connection;
	static CSocket2SerialNoSet setSocket2SerialNo;
	static CNetSock aSock[FD_SETSIZE];
	static uint64_t nSerialNo;
	static int aPipe[2];

	static void *ProcessThread(void *);

	int nSock;
	std::string strIP;
	uint16_t nPort;

	void InnerInit();
public:
	static bool StaticInit();
	static bool Interaction(CNetClientInteraction *pInteractions, uint32_t nLen, uint32_t nTimeout); //msec

	void Init();
	CNetClientConnection();
	~CNetClientConnection();
	bool Connect(const std::string &strIP, uint16_t nPort);
	bool Send(const CNetMessage &oMsg, uint32_t nTimeout);
	bool Recv(CNetMessage &oMsg, uint32_t nTimeout);
	bool SendRequest(const CNetMessage &oRequestMsg, CNetMessage &oResponseMsg, uint32_t nTimeout);
};

class CNetServerFrame
{
private:
	typedef std::list<std::pair<int, CNetMessage> > CMsgList;

	static pthread_mutex_t lock;
	static pthread_cond_t condInc;
	static CMsgList lstMsg;
	static CNetSock aSock[FD_SETSIZE];
	static int nListenSock;
	static uint32_t nTimeout;
	static int aPipe[2];

	static void *ProcessThread(void *);
public:
	static bool StaticInit(const std::string &strIP, uint16_t nPort, uint32_t nTimeout);
	static bool GetRequest(int &nSock, CNetMessage &oRequestMsg);
	static bool PutResponse(int nSock, const CNetMessage &oResponseMsg);
};

}
}

#endif
