#ifndef LISTEN_THREAD_H
#define LISTEN_THREAD_H

#include "gcommon.h"
	
class CListenThread
{
private:
		int m_nPort;
		int m_nEpollSocket;
		
public:
	CListenThread();
	CListenThread(int nPort);
	virtual ~CListenThread();
	
	int nCreateThread();
	void vEndThread();
	
	void vSetBlocking(int nSock);
	static void vListenFunc(void *Param);
	
	void SetPort(int nPort) {m_nPort = nPort;} 
	int  GetPort() {return m_nPort;} 	
	
public:
	deque<int> m_DataQue;
	sem_t m_Sem;  
	pthread_mutex_t m_Mutex;

	
protected:
	pthread_t m_threadHandler;    //�߳̾��
};

#endif