#ifndef ALGORITHM_GEN_SIGN_H
#define ALGORITHM_GEN_SIGN_H

#include <stdint.h>
#include <string>


namespace sn_common
{

class CSign
{
private:
	uint64_t m_nSign;
public:
	CSign();// m_nSign(1)
	CSign(uint64_t nSign);// m_nSign(nSign)
	~CSign();
	CSign& Add(const void *pvInput, size_t nSize);
	CSign& Add(const std::string &strInput);
	CSign& Add(const char *pszInput);
	uint64_t GetSign() const;  
	static uint64_t GetSign(const void *pvInput, size_t nSize);
	static uint64_t GetSign(const std::string &strInput);
	static uint64_t GetSign(const char *pszInput);
};

}
#endif
