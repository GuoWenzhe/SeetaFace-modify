#ifndef _CFLANNSEARCH_H_
#define _CFLANNSEARCH_H_

#include <flann/flann.hpp>
#include <flann/io/hdf5.h>

#include <stdio.h>
#include <time.h>

using namespace std;
using namespace flann;

class CFlannSearch{
    public:
        CFlannSearch();
        /**
         * \brief Constructor
         * \param[in] the hdf5 data file
         * \param[in] the dataset name in the hdf5 file
         * \param[in] the index file
         */
        CFlannSearch(const string &data_file,
                     const string &dataset_name,
                     const string &index_file);

        /**
         * \brief search the nearest neighbor's index and weight
         * \param[in] the query ( a vector<float> )
         * \param[in] the precision (specifies the maximum leafs)
         * \param[in] how many result you want
         * \param[out] the result ( a vector<int> )
         * \param[out] the weight ( a vector<float> )
         */
        int Search(const vector<float> &v_query,
                   const int precision,
                   const int num,
                   vector<int> &v_result,
                   vector<float> &v_weight);
        ~CFlannSearch();
    private:
        Index<L2<float> > *index_;
};

#endif
