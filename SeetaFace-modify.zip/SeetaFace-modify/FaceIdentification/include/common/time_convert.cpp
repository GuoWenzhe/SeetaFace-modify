#include <string.h>
#include <stdio.h>
#include "time_convert.h"

using namespace std;
namespace sn_common
{
STime::STime()
{
	memset(this, 0, sizeof(*this));
}

bool SplitTime(time_t nTime, STime &oTime)
{
	tm tm1;
	memset(&tm1, 0, sizeof(tm1));
	memset(&oTime, 0, sizeof(oTime));
	if (nTime >= 0)
	{
		localtime_r(&nTime, &tm1);
		oTime.year = tm1.tm_year + 1900;
		oTime.month = tm1.tm_mon + 1;
		oTime.day = tm1.tm_mday;
		oTime.hour = tm1.tm_hour;
		oTime.minute = tm1.tm_min;
		oTime.second = tm1.tm_sec;
		oTime.week_day = tm1.tm_wday;
		return true;
	}
	return false;
}
//STime ת time_t
bool JoinTime(const STime &oTime, time_t &nTime)
{
	nTime = -1;
	tm tm1;
	memset(&tm1, 0, sizeof(tm1));
	if (1970 <= oTime.year && 1 <= oTime.month && oTime.month <= 12 && 1 <= oTime.day && oTime.day <= 31 && oTime.hour <= 23 && oTime.minute <= 59 && oTime.second <= 59)
	{
		tm1.tm_year = oTime.year - 1900;
		tm1.tm_mon = oTime.month - 1;
		tm1.tm_mday = oTime.day;
		tm1.tm_hour = oTime.hour;
		tm1.tm_min = oTime.minute;
		tm1.tm_sec = oTime.second;
		nTime = mktime(&tm1);
	}
	return (nTime != -1);
}
bool TimeToStr(time_t nTime, string &strTime, bool bShowWeekDay)
{
	static const char *aWeekDays[] = {
		"������",
		"����һ",
		"���ڶ�",
		"������",
		"������",
		"������",
		"������"
	};
	strTime.clear();
	STime oTime;
	if (!SplitTime(nTime, oTime))
		return false;
	char aBuf[80];
	snprintf(aBuf, sizeof(aBuf), "%4.4u-%2.2u-%2.2u %2.2u:%2.2u:%2.2u", oTime.year, oTime.month, oTime.day, oTime.hour, oTime.minute, oTime.second);
	strTime.append(aBuf);
	assert(oTime.week_day <= 6);
	if (bShowWeekDay)
	{
		strTime.append(" ");
		strTime.append(aWeekDays[oTime.week_day]);
	}
	return true;
}
bool StrToTime(const string &strTime, time_t &nTime)
{
	bool bSucc = false;
	nTime = -1;
	STime oTime;
	uint32_t year, month, day, hour, minute, second;
	if (6 == sscanf(strTime.c_str(), "%u-%u-%u %u:%u:%u", &year, &month, &day, &hour, &minute, &second) && 1970 <= year && year <= 0xffff && 1 <= month && month <= 12 && 1 <= day && day <= 31 && hour <= 23 && minute <= 59 && second <= 59)
	{
		oTime.year = year;
		oTime.month = month;
		oTime.day = day;
		oTime.hour = hour;
		oTime.minute = minute;
		oTime.second = second;
		bSucc = JoinTime(oTime, nTime);
	}
	return bSucc;
}

string TimeToStr(time_t nTime, bool bShowWeekDay)
{
	string strTime;
	TimeToStr(nTime, strTime, bShowWeekDay);
	return strTime;
}

}
