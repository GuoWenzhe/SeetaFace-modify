#include "xml_http.h"
#include <iostream>
#include <string.h>

using namespace std;

cxmlhttp::cxmlhttp()
{

}

cxmlhttp::~cxmlhttp()
{

}
/*
int cxmlhttp::parserequest(string strRecvPara,hash_map<string,string>& hmStrStr)
{
	if(strRecvPara.length()==0)
		return 0;

	string::iterator itStr;
	string::iterator itStrT;
	string m_strEncodedKeyWord;
	string strName,strValue;


	for (itStr=strRecvPara.begin();itStr!=strRecvPara.end();++itStr)
	{
		itStrT=itStr;
		while(itStr!=strRecvPara.end()&&*itStr!='=')
		{
			++itStr;
		}


		if (itStr==strRecvPara.end())
		{
			break;
		}
		else
		{
			strName.assign(itStrT,itStr);
			if (strValue.empty())
			{
				strValue="";
			}
			itStrT=itStr;
		}

		while (itStr!=strRecvPara.end()&&*itStr!='&')
		{
			++itStr;
		}

		strValue.assign(++itStrT,itStr);
		if (strValue.empty())
		{
			strValue="";
		}

		string ret;
		string gbk;
		ret = URLDecode(strValue);
		Utf8ToGbk(ret, gbk);
		hmStrStr[strName]=gbk;
		if (itStr==strRecvPara.end())
		{
			break;
		}
	}
	return 0;

}
*/
string& cxmlhttp::xmlencode(const char *str, string& s)
{
	if(!str) return s;
	while(*str)
	{
		switch(*str)
		{
			case '<':
				s+="&lt;";
				break;
			case '>':
				s+="&gt;";
				break;
			case '&':
				s+="&amp;";
				break;
			case '\'':
				s+="&apos;";
				break;
				case '\"':
					s+="&quot;";
				break;
			default:
               s+=*str;
			/*	if(*str>=0)
				{
					if((*str>=0x00&&*str<=0x08)||(*str==0x0c)||(*str==0x0b)||(*str>=0x0e&&*str<=0x1f))
						;
					else
						s+=*str;
				}
				else
				{
					if(*(str+1)==0)
						return s;;
					s+= *str++;
					s+=*str;
				}*/
		}
		str++;
	}
	return s;
}

string& cxmlhttp::xmlpacktext(const char *str, string& s)
{
	if(!str) return s;
	s+="<![CDATA[ ";
	while(*str)
	{
		if(*str>=0)
		{
			if((*str>=0x00&&*str<=0x08)||(*str==0x0c)||(*str==0x0b)||(*str>=0x0e&&*str<=0x1f))
				;
			else
				s+=*str;
		}
		else
		{
			if(*(str+1)==0)
				break;
			s+= *str++;    
			s+=*str;
		}      
		str++;
	}
	s+=" ]]>";
	return s;
}

string cxmlhttp::urlencode(string sIn)
{

	string sOut;
	const int nLen = sIn.length();
	unsigned char ch;

	for(int i=0;i<nLen;i++)
	{
		ch=sIn[i];
		if(isalnum(ch))
			sOut+=ch;
		else if(isspace(ch))
			sOut+="%20";
		else{
			sOut+="%";
			sOut+=toHex(ch>>4);
			sOut+=toHex(ch%16);
		}
	}
	return sOut;

}

bool cxmlhttp::utf8togbk(const string &strInput, string &strOutput)
{
	static iconv_t cd = iconv_open("GBK", "UTF8");

	strOutput.clear();
	char *inbuf = (char *)strInput.c_str();
	char *outbuf = (char *)malloc(strInput.length());
	char *outbuf_head = outbuf;
	size_t inbytesleft = strInput.length();
	size_t outbytesleft = strInput.length();
	size_t nRet = iconv(cd, &inbuf, &inbytesleft, &outbuf, &outbytesleft);
	iconv(cd, NULL, NULL, NULL, NULL);

	strOutput.append(outbuf_head, outbuf-outbuf_head);
	free(outbuf_head);

	return ((size_t)-1 != nRet);
}

string cxmlhttp::urldecode(const string& URL)
{
	string result = "";
	for ( unsigned int i=0; i<URL.size(); i++ ) {
		char c = URL[i];
		if ( c != '%' ) {
			if(c == '+')
				result += ' ';
			else
				result += c;
		}   
		else if( (i+2)<URL.size())
		{   
			char c1 = URL[++i];
			char c0 = URL[++i];
			int num = 0;
			num += hexChar2dec(c1) * 16 + hexChar2dec(c0);
			result += char(num);
		}   
	}   
	return result;

}

