#include "file_writer.h"

using namespace std;

namespace sn_common{
namespace io_util{
	
/**
 * @brief ���ļ�
 *
 * @param [in]	  fileName	  : �ļ���
 * @param [out]   iBuffSize   : ��������С
 * @return	0:�ɹ�	 -2:�ļ���Ϊ�� -3:���ļ�ʧ�� 
 * @note	
**/
int FileWriter::Open(const string& fileName)
{
	int rs = 0;

	if (m_fileClosed == false)
	{
		// ERROR
		// throw ("open file again\n");
		// rs = -1;
		
		// WARNING
		// reOpen another file
		Close();
	}

	if (fileName.empty())
	{
		rs = -2;
	}
	else
	{
		m_desFile.open(fileName.c_str(), ios::binary|ios::out);

		if (!m_desFile)
		{
			// ERROR
			// ...
			rs = -3;
		}
		else
		{
			// open success
			m_fileClosed = false;
		}
	}

	return rs;
}

/**
 * @brief �ر��ļ�
 *
 * @param [in]    
 * @param [out]   
 * @return  0:�ɹ�  
 * @note    
**/
int FileWriter::Close()
{
	int rs = 0;			
	
	if (m_fileClosed == true)
	{
		// WARNING
		// the file is already closed :)
	}
	else
	{
		if (m_desFile)
		{
			m_desFile.close();
		}
	}

	return rs;
}

/**
 * @brief д�ļ�
 *
 * @param [in]    *src: 	ִ��Դ����
 * @param [in]    srcLen:	Ҫд������ݳ���
 * @param [out]   
 * @return  >0:�ɹ� ����д����ֽ���  -1:�ļ�һ�ر� -2:�ļ�������Ϊ�� -3:д������Ϊ�� -4 д�ļ�ʧ��
 * @note    
**/
int FileWriter::Write(const void *src, unsigned long srcLen)
{
	int rs = 0;		
	
	if (m_fileClosed == true)
	{
		// ERROR
		// ...
		rs = -1;
	}
	else
	{
		if (!m_desFile)
		{
			// ERROR
			// file is NOT open, cannot WRITE
			rs = -2;
		}
		else
		{
			if (src == NULL)
			{
				// ERROR
				rs = -3;
			}
			else
			{
				if (m_desFile.write((char*)src, sizeof(char) * srcLen))
				{
					rs = srcLen;
				}
				else
				{
					// ERROR
					// ...
					rs = -4;
				}
			}
		}
	}
				
	return rs;
}

}
}
