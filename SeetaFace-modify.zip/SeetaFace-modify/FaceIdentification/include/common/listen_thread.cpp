#include "listen_thread.h"


CListenThread::CListenThread()
{
	m_nPort = -1;
	m_nEpollSocket = -1;
}

CListenThread::~CListenThread()
{
	vEndThread();
}

int CListenThread::nCreateThread()
{
	if(m_nPort<=0)
	{
		return -1;
	}
	
	int nRes = pthread_mutex_init(&m_Mutex,NULL);
	if(nRes!=0)
	{
		perror("listenThread init mutex error");
		return -1;
	}

	nRes = sem_init(&m_Sem,0,0);
	if(nRes!=0)
	{
		perror("listenThread init sem error");
		return -1;
	}
	
	return (pthread_create(&m_threadHandler,NULL,(void*(*)(void*))&vListenFunc,(void *)this));   

}

void CListenThread::vEndThread()
{
	if(-1!=m_nEpollSocket)
	{
		close(m_nEpollSocket);
	}
}

void CListenThread::vListenFunc(void *Param)
{
	CListenThread *pThread = (CListenThread *)Param;
	
	int nListenfd = -1;
	int nNewfd = -1;

	//create socket
	nListenfd= socket(AF_INET, SOCK_STREAM, 0);
	int nReuseAddr = 1;
	if(setsockopt(nListenfd, SOL_SOCKET, SO_REUSEADDR, &nReuseAddr, sizeof(nReuseAddr))==-1)
	{
		perror("set socket reuse fail:");
	}
	
	socklen_t clilen;
	struct sockaddr_in clientaddr, serveraddr;
	memset(&serveraddr, 0, sizeof(serveraddr));
		serveraddr.sin_family = AF_INET;
		serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
		serveraddr.sin_port=htons(pThread->m_nPort);
	//printf("***********************listen port :%d\n", pThread->m_nPort);
		// bind and listen
	while(bind(nListenfd,(sockaddr *)&serveraddr, sizeof(serveraddr))<0)
	{
		//perror("bind socket error");
		LOG(ERROR)<<"Bind error:"<<strerror(errno);  	
		sleep(1);
	}
	while(listen(nListenfd, 5)<0)
	{
		//perror("listen error ");
		LOG(ERROR)<<"Listen error:"<<strerror(errno); 
		sleep(1);
	}
	
   	pThread->m_nEpollSocket = epoll_create(256);
  	if(-1==pThread->m_nEpollSocket)
   	{
   		//perror("epoll_create error");
		LOG(ERROR)<<"epoll_create error:"<<strerror(errno); 
   		return;
   	}
	
  	struct epoll_event ev;
   	struct epoll_event events[20];
   	memset((void *)&ev,0,sizeof(struct epoll_event));
   	
   	for(int ii=0;ii<20;ii++)
   	{
   		memset((void *)&events[ii],0,sizeof(struct epoll_event));
   	}
	
	ev.data.fd = nListenfd;
	ev.events = EPOLLIN;	
  	if(-1==epoll_ctl(pThread->m_nEpollSocket,EPOLL_CTL_ADD,nListenfd,&ev))
   	{
   		//perror("epoll_ctl add fd error");
   		LOG(ERROR)<<"epoll_ctl add error:"<<strerror(errno); 
   		return;   		
   	}
   
	while(true)
	{
		int nfds = epoll_wait(pThread->m_nEpollSocket, events, 20, -1);
		if(-1==nfds)
		{
			if(errno==EINTR)
			{
				//perror("epoll_wait was EINTR");
				continue;
			}
			else
			{
				perror("epoll_wait error ");
				exit(1);
			}
		}
		
		for (int i = 0; i < nfds; i++)
		{
			if (events[i].data.fd == nListenfd)
			{	
				memset(&clientaddr, 0, sizeof(clientaddr));
				nNewfd = accept(nListenfd,(sockaddr *)&clientaddr, &clilen);
				if(nNewfd<0)
				{
					//perror("accept error ");
					LOG(ERROR)<<"Accept add error:"<<strerror(errno); 
					return ;
				}
			   
				//add to deque and send sem
				//char *str = inet_ntoa(clientaddr.sin_addr);
				//std::cout << "accapt a connection from " << str << std::endl;
				pthread_mutex_lock(&pThread->m_Mutex);
				pThread->m_DataQue.push_back(nNewfd);
				pthread_mutex_unlock(&pThread->m_Mutex);
				
				sem_post(&pThread->m_Sem);
				
				
			}
		}
	}
	return;
}

