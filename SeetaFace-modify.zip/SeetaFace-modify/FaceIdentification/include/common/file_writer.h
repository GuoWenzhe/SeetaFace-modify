#ifndef FILESYSTEM_FILE_WRITER_H
#define FILESYSTEM_FILE_WRITER_H

#include <string>
#include <fstream>

namespace sn_common
{
namespace io_util
{	
	class FileWriter
	{
	public:
		FileWriter()
			:m_fileClosed(true)
		{}

		
		virtual ~FileWriter()
		{
			Close();
		}
		
        int Open(const std::string& fileName);

		int Close();

		int Write(const void *src, unsigned long srcLen);

	private:
        std::ofstream m_desFile;

		bool m_fileClosed;
	};
}
}
#endif
