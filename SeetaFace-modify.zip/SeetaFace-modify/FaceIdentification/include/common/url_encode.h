#ifndef NET_URL_ENCODE_H
#define NET_URL_ENCODE_H

#include <string>

namespace sn_common
{
//URL编解码
std::string URLDecode(const std::string &URL);
std::string URLEncodeAll(const std::string &src);
std::string URLEncode(const std::string &src);

}

#endif

